import React from 'react'
import StarWars from './StarWars'

function App() {
  return (
    <div>
      <StarWars />
    </div>
  )
}

export default App
