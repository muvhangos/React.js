import React from 'react'
import Tweet from './Tweet'

function App() {
  return (
    <Tweet tweetId="1" />
  )
}

export default App
